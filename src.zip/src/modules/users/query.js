const GET_USERS = `
	SELECT 
		*
	FROM users;
`

module.exports = {
	GET_USERS,
}